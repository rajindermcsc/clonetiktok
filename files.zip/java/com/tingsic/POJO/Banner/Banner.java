package com.tingsic.POJO.Banner;

public class Banner {
    private String path,image;

    public Banner(String path, String image) {
        this.path = path;
        this.image = image;
    }

    public String getPath() {
        return path;
    }

    public String getImage() {
        return image;
    }

}
