package com.tingsic.Fragment.RelateFrags;

public interface OnBackPressListener {
    boolean onBackPressed();
}
