package com.tingsic.Listner;

import com.tingsic.POJO.People;

public interface OnPeopleListener {
    void onListClicked(People people);
}
