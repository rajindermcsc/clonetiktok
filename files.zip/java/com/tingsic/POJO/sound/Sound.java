package com.tingsic.POJO.sound;

public class Sound {
    public String id,sound_name,description,section,thum,date_created;
    public String mp3_path,acc_path;

}
