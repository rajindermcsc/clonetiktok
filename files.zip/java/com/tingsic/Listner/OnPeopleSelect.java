package com.tingsic.Listner;

public interface OnPeopleSelect {
    void onPeopleSelected(String userId);
}
