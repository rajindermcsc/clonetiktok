package com.tingsic.Listner;

public interface OnLoadMoreListener {
    void onLoadMore();
}
