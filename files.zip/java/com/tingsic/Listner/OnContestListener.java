package com.tingsic.Listner;

import com.tingsic.POJO.Contest.Response.Contest;

public interface OnContestListener {
    void onContestSelected(Contest contest);
}
