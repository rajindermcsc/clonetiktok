package com.tingsic.POJO.service;

public class Data {
}
