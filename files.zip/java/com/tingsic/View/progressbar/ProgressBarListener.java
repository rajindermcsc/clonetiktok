package com.tingsic.View.progressbar;

public interface  ProgressBarListener {

    void TimeinMill(long mills);
}