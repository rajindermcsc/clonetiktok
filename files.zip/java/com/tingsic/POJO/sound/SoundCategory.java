package com.tingsic.POJO.sound;

import java.util.ArrayList;

public class SoundCategory {
    public String catagory;
    public ArrayList<Sound> sound_list=new ArrayList<>();
}
