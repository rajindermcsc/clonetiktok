package com.tingsic.VideoCompress;

public interface InitListener {
    void onLoadSuccess();
    void onLoadFail(String reason);
}
