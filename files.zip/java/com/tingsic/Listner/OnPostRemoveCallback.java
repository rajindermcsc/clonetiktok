package com.tingsic.Listner;

public interface OnPostRemoveCallback {

    void onSuccess(int position);
    void onFail();

}
