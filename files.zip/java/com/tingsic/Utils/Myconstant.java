package com.tingsic.Utils;
public class Myconstant
{
    public static String Sharedprefernce="shared";
    public static String USER_LOGINID="userloginid";
    public static String DATABASE_NAME="Notification.db";
}
