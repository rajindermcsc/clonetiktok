package com.tingsic.Listner;

public interface OnPostRemoveListener {
    void onPostRemoved(int position, OnPostRemoveCallback onPostRemoveCallback);
}
