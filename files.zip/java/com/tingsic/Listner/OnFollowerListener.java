package com.tingsic.Listner;

public interface OnFollowerListener {
    void onFollowerSelected(String userId);
}
